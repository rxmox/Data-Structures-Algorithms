I have created a separate file for the bonus.

There have been a couple of slight changes I made to the skeleton code provided in order to get the bonus to work:
-Added bidirectional edges
-changed the printDistanceAndShortestPathFromSource method to get expected output
-Added buildCanadaGraph to build the graph outlined in spec sheet
-added removeEdgesConnectedTo for part B

Each java file should be able to run separately perfectly fine