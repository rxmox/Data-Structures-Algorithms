Hello,

For this program to work you must type the input and output file names, otherwise it will not work.
The specs file did not specify how data should be inputted, and when I asked the professor he said
I can do whatever as long as it is not specified.I believe this is a better way than hardcoding the path.
Also this program only takes 1 input file at a time

I have also changed the main method from what was provided in the skeleton, to assist me with debugging.
It functions exactly the same way, and it even makes things much clearer.

I have added 2 functions mergeSort and merge, since the professor mentioned that I am not allowed to use
Array.sort()
I have used the following link to assist me with writing these 2 functions:
https://www.geeksforgeeks.org/merge-sort/


I have spent countless hours to get this program to work, and I have made sure the test files work
perfectly fine.


If there is anything that is unclear please do not hesitate to contact me:
omar.ahmed@ucalgary.ca



